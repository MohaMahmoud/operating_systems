#ifndef PIPE_H
#define PIPE_H

int run_program(char *file_path, char *argv[]);

#endif