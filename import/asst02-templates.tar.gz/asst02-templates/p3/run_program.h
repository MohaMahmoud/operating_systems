#ifndef RUN_PROGRAM_H
#define RUN_PROGRAM_H

int run_program(char *file_path, char *argv[]);

#endif

