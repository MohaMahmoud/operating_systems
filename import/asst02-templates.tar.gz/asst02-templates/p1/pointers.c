#include "pointers.h"

int average(int *arrayPointer, unsigned int size)
{
    (void) arrayPointer;
    (void) size;
    return 0;
}

int averageIndirect(int **arrayPointer, unsigned int size)
{
    (void) arrayPointer;
    (void) size;
    return 0;
}
