#ifndef INSERT_H
#define INSERT_H

#include <stddef.h>

void insert(int **array, size_t *length, size_t *capacity, int z);

#endif
