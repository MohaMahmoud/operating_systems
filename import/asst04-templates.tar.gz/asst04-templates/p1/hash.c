#include "hash.h"

/*
 * Returns a hash value for the given string.
 */
uint64_t hashString(char *c)
{
	(void) c;
	return 0;
}

/*
 * Inserts a key-value pair into the hash table.
 */
int insert(hashtable *table, char *key, int value)
{
	(void) table; (void) key; (void) value;
	return 0;
}

/*
 * Retrieves the value for a given key.
 */
int find(hashtable *table, char *key, int *value)
{
	(void) table; (void) key; (void) value;
	return 0;
}

